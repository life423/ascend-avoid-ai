// src/core/MultiplayerGameMode.ts
import GameMode from './GameMode';
import { InputState, NetworkPlayer } from '../types';
import { MultiplayerManager } from '../managers/MultiplayerManager';
import { EventBus } from './EventBus';
import { GameEvents } from '../constants/client-constants';

const PLAYER_COLORS = [
  '#FF5252', '#FF9800', '#FFEB3B', '#4CAF50', 
  '#2196F3', '#9C27B0', '#E91E63', '#00BCD4'
];

export default class MultiplayerGameMode extends GameMode {
  private multiplayerManager: MultiplayerManager;
  private eventBus: EventBus;
  private players: Map<string, NetworkPlayer> = new Map();
  private localSessionId: string = '';
  private lastInputSent: number = 0;
  private inputSendRate: number = 50;

  constructor(game: any) {
    super(game);
    this.eventBus = game.eventBus || new EventBus();
    this.multiplayerManager = new MultiplayerManager(this.eventBus, game.assetManager || null);
    this.setupEventListeners();
  }

  private setupEventListeners(): void {
    this.eventBus.on(GameEvents.MULTIPLAYER_CONNECTED, (data) => {
      console.log('🔗 Connected to multiplayer:', data);
      this.localSessionId = data.sessionId;
      console.log('🎯 My session ID:', this.localSessionId);
      // No local player creation - all players come from server
    });

    this.eventBus.on(GameEvents.MULTIPLAYER_STATE_UPDATE, (state) => {
      this.handleStateUpdate(state);
    });

    this.eventBus.on(GameEvents.PLAYER_JOINED, (data) => {
      console.log('👤 Player joined:', data);
    });

    this.eventBus.on(GameEvents.PLAYER_LEFT, (data) => {
      console.log('👋 Player left:', data);
      this.players.delete(data.id);
    });
  }

  async initialize(): Promise<void> {
    await super.initialize();
    console.log('🎮 Initializing multiplayer mode...');
    
    try {
      const connected = await this.multiplayerManager.connect();
      if (!connected) {
        console.log('⚠️ Server not available, falling back to single player');
        await (this.game as any).switchGameMode('singlePlayer');
        return;
      }
      
      this.game.isMultiplayerMode = true;
      console.log('✅ Multiplayer mode initialized successfully');
    } catch (error) {
      console.error('❌ Failed to initialize multiplayer:', error);
      await (this.game as any).switchGameMode('singlePlayer');
    }
  }

  private handleStateUpdate(state: any): void {
    console.log('📡 State update - Total players:', state.totalPlayers);
    
    if (!state || !state.players) {
      console.log('⚠️ No players in state');
      return;
    }

    // Clear all players
    this.players.clear();

    // Process all players from server - treat all equally
    state.players.forEach((playerData: any, sessionId: string) => {
      console.log(`🔍 Player ${sessionId}: (${playerData.x}, ${playerData.y})`);
      this.addPlayer(sessionId, playerData);
    });

    console.log(`✅ Final: ${this.players.size} total players`);
  }

  private addPlayer(sessionId: string, playerData: any): void {
    const playerIndex = this.players.size;
    const x = Math.max(50, Math.min(playerData.x || (100 + playerIndex * 80), 700));
    const y = Math.max(50, Math.min(playerData.y || (200 + playerIndex * 60), 800));
    
    const player: NetworkPlayer = {
      id: sessionId,
      sessionId: sessionId,
      x: x,
      y: y,
      name: playerData.name || `Player ${playerIndex + 1}`,
      color: PLAYER_COLORS[playerIndex % PLAYER_COLORS.length],
      isAlive: true,
      score: 0,
      lastUpdate: Date.now()
    };
    
    this.players.set(sessionId, player);
    const isMe = sessionId === this.localSessionId ? ' (ME)' : '';
    console.log(`➕ Added player: ${sessionId}${isMe} at (${x}, ${y}) Color: ${player.color}`);
  }

  update(inputState: InputState, _deltaTime: number, timestamp: number): void {
    if (this.game.obstacleManager) {
      this.game.obstacleManager.update(timestamp, this.game.score, this.game.scalingInfo);
    }
    
    // Send input to server at regular intervals
    const now = Date.now();
    if (now - this.lastInputSent >= this.inputSendRate) {
      this.sendInputToServer(inputState);
      this.lastInputSent = now;
    }
  }



  private sendInputToServer(inputState: InputState): void {
    if (!this.multiplayerManager.isConnected()) return;
    
    const input = {
      up: inputState.up || false,
      down: inputState.down || false,
      left: inputState.left || false,
      right: inputState.right || false
    };
    
    this.multiplayerManager.sendInput(input);
  }

  render(ctx: CanvasRenderingContext2D, timestamp: number): void {
    if (!ctx) return;
    
    (this.game as any).renderSharedScene(ctx, timestamp);
    this.renderAllPlayers(ctx, timestamp);
  }

  private renderAllPlayers(ctx: CanvasRenderingContext2D, _timestamp: number): void {
    console.log(`🎨 Rendering: ${this.players.size} total players`);
    
    // Render all players from server state
    this.players.forEach((player, sessionId) => {
      const isMe = sessionId === this.localSessionId;
      const playerType = isMe ? 'ME' : 'OTHER';
      console.log(`🎨 Drawing ${playerType} ${sessionId} at (${player.x}, ${player.y}) ${player.color}`);
      
      ctx.save();
      ctx.fillStyle = player.color;
      ctx.fillRect(player.x, player.y, 30, 30);
      
      // Yellow border for your own player, white for others
      ctx.strokeStyle = isMe ? '#ffff00' : '#ffffff';
      ctx.lineWidth = isMe ? 3 : 2;
      ctx.strokeRect(player.x, player.y, 30, 30);
      ctx.restore();
    });
  }

  postUpdate(): void {}
  reset(): void {}
  completeReset(): void {}
  
  dispose(): void {
    super.dispose();
    this.multiplayerManager.disconnect();
    this.players.clear();
  }
}